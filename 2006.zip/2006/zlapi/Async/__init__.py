# -*- coding: UTF-8 -*-
"""Zalo API for Python

:copyright: (c) 2024 by Lê Quốc Việt (Vexx).
"""
from ._async import ZaloAPI

__all__ = ["ZaloAPI"]
